﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okcu_Library
{
    class Ok:Cisim
    {
        private Okcu _okcu;
        public Ok(string gorselKonum, Size hareketAlaniBoyutlari, Okcu okcu) : base(hareketAlaniBoyutlari)
        {
            _okcu = okcu;
            Image = Image.FromFile(gorselKonum);
            HareketMesafesi = 40;
            BaslangicKonumuAyarla();
        }

        private void BaslangicKonumuAyarla()
        {
            Top = _okcu.Top+50;
            Left = 0;
        }
    }
}
