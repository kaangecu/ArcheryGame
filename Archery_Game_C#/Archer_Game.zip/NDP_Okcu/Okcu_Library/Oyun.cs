﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using Okcu_Library.Enum;
using Okcu_Library.Balonlar;
using System.IO;

namespace Okcu_Library
{
    public class Oyun
    {
        private Timer _sureTimer = new Timer { Interval=1000};
        private Timer _hareketTimer = new Timer { Interval = 100 };


        //farklı renkteki balonların istenilen oranlarda düşmesi için timerları ona göre oranlanmıştır
        private Timer _greenBalonTimer = new Timer { Interval = 1000*2};
        private Timer _yellowBalonTimer = new Timer { Interval = 3330*2 };
        private Timer _redBalonTimer = new Timer { Interval = 5000*2 };

        private TimeSpan _gecenSure;
        private int _puan = 0;
        private bool ikinciAsama = false, ucuncuAsama = false;

        //pictureboxlaarın sınırlarının belirlenmesi için paneller kullanılıyor
        private readonly Panel _okcuPanel, _anaPanel,_balonPanel;
        private readonly string[] _oyuncuBilgileri;             //burada ilk ekranda seçilen görseller renk ve isim tutuluyor
        private Okcu okcu;



        private readonly List<Ok> oklar = new List<Ok>();
        private readonly List<Balon> balonlar = new List<Balon>();

        public event EventHandler GecenSureEvent;
        public event EventHandler PuanDegistiEvent;

        public bool DevamEdiyorMu { get; private set;}

        public TimeSpan GecenSure       //private olan GecenSureyi dışarıdan ulaşabilmek için
        { get => _gecenSure;
            private set
            {
                _gecenSure = value;
                GecenSureEvent?.Invoke(this, EventArgs.Empty);
            } 
        }

        public int Puan                 /////private olan Puana dışarıdan ulaşabilmek için
        {
            get => _puan;
            private set
            {
                _puan = value;
                PuanDegistiEvent?.Invoke(this, EventArgs.Empty);
            }
        }

        //constructer da gelen değişkenlerin sınıf içinde ataması ve tick eventlerinin fonksiyonlara bağlanması yapılıyor
        public Oyun(Panel okcuPanel,Panel anaPanel, Panel balonPanel, string[] oyuncuBilgileri)
        {

            _okcuPanel = okcuPanel;
            _anaPanel = anaPanel;
            _balonPanel = balonPanel;
            _oyuncuBilgileri = oyuncuBilgileri;

            _sureTimer.Tick += SureTimer_Tick;
            _hareketTimer.Tick += HareketTimer_Tick;

            _greenBalonTimer.Tick += GreenBalon_Tick;
            _yellowBalonTimer.Tick += YellowBalon_Tick;
            _redBalonTimer.Tick += RedBalon_Tick;
        }

        //sağ üstte bulunan süreyi artıran event
        private void SureTimer_Tick(object sender, EventArgs e)
        {

            GecenSure += TimeSpan.FromSeconds(1);
        }

        //nesnelerin hareketini sağlayan event
        private void HareketTimer_Tick(object sender, EventArgs e)
        {

            OklariHareketEttir();
            BalonHareketEttir();
            BalonPatlat();
        }


        private void GreenBalon_Tick(object sender, EventArgs e)
        {
            greenBalonOlustur();
        }

        private void YellowBalon_Tick(object sender, EventArgs e)
        {
            if (ikinciAsama)
                yellowBalonOlustur();
        }

        private void RedBalon_Tick(object sender, EventArgs e)
        {
            if (ucuncuAsama)
                redBalonOlustur();

        }

        private void OklariHareketEttir()   //okları hareket ettirir eğer sınırları dışına çıkarsa çıkan oku siler
        {
            for (int i = oklar.Count-1; i >= 0; i--)
            {
                var ok = oklar[i];
                var carptiMi = ok.HareketEttir(Yon.Sag);
                if (carptiMi)
                {
                    oklar.Remove(ok);
                    _balonPanel.Controls.Remove(ok);
                    
                }
            }
        }

        public void BalonHareketEttir()     //balonları hareket ettirir eğer balon en aşağı varırsa oyun biter
        {
            foreach (var balon in balonlar)
            {
                var carptiMi = balon.HareketEttir(Yon.Asagı);
                if (!carptiMi) continue;
                
                Bitir();
                break;
            }

        }

        private void BalonPatlat()      //okla balonun kesiştiği noktada balonu siler
        {

            for (int i = balonlar.Count - 1; i >= 0; i--)
            {
                var balon = balonlar[i];

                var vurulduMu = balon.VurulduMu(oklar);
                if (!vurulduMu) continue;

                Puan += balon.Puan;
                balonlar.Remove(balon);
                _balonPanel.Controls.Remove(balon);
               
                if (balon.renk == Balon.Renk.Red)
                    Puan = 0;

            }
            if (Puan == 100 && ikinciAsama==false && ucuncuAsama == false)      //puan belirlenen eşiğe ulaştığında hız artar
            {
                _hareketTimer.Interval = 80;
                ikinciAsama = true;
            }

            if (Puan >= 200 && ucuncuAsama == false && ikinciAsama == true)     //puan belirlenen eşiğe ulaştığında hız artar
            {
                _hareketTimer.Interval = 60;
                ucuncuAsama = true;
            }  
        }

        public void Baslat()        //timerları başlatır ve oyun alanını hazırlar
        {
            if (DevamEdiyorMu) return;

            DevamEdiyorMu = true;
            
            _sureTimer.Start();
            _hareketTimer.Start();
            _greenBalonTimer.Start();
            _yellowBalonTimer.Start();
            _redBalonTimer.Start();

            okcu = new Okcu(_oyuncuBilgileri[2],_okcuPanel.Size, _okcuPanel.Width);     //oyun başladığında okçuyu oluşturur
            

            _okcuPanel.Controls.Add(okcu);                                              //okçuyu ekrana çizer
            _anaPanel.Visible = true;                                                     
            _anaPanel.BackColor = Color.FromName(_oyuncuBilgileri[4]);                  //seçilen arkaplan rengini ayarlar
            

        }

        public void Bitir()         //balon aşağı ulaştığında programı durdurur
        {
            if (!DevamEdiyorMu) return;

            DevamEdiyorMu = false;
            _sureTimer.Stop();
            _hareketTimer.Stop();
            _greenBalonTimer.Stop();
            _yellowBalonTimer.Stop();
            _redBalonTimer.Stop();

            _oyuncuBilgileri[1] = Puan.ToString();      //dosyaya kaydetmek için son puanı tutuyor
            string bilgiler ="";
            for (int i = 0; i <= 4; i++)                //burda oyuncunun ilk ekranda seçtiği seçenekler ve adı dosyaya yazılmak üzerine bir stringe uygun formatta yazılıyor
            {
                if (i == 4)
                {                  
                    bilgiler += _oyuncuBilgileri[i];
                } 
                else
                bilgiler += _oyuncuBilgileri[i] + " ";
            }
            using (TextWriter bilgileriKaydet = new StreamWriter(@"Text\player.txt",true))  //dosyaya yazma işlemi
            {
                bilgileriKaydet.WriteLine(bilgiler);
            }

            MessageBox.Show("Oyun Sona Erdi");      
        }

        public void AtesEt()        //ok sayısı 50yi geçmeyecek şekilde oklar oluşturuyor
        {
            if (oklar.Count <= 50)
            {
                Ok ok = new Ok(_oyuncuBilgileri[3], _balonPanel.Size, okcu);
                oklar.Add(ok);
                _balonPanel.Controls.Add(ok);
            }
        }

        public void greenBalonOlustur()
        {
            YesilBalon balon = new YesilBalon(_balonPanel.Size);
            balonlar.Add(balon);
            _balonPanel.Controls.Add(balon);

        }

        public void yellowBalonOlustur()
        {
            SariBalon balon = new SariBalon(_balonPanel.Size);
            balonlar.Add(balon);
            _balonPanel.Controls.Add(balon);

        }

        public void redBalonOlustur()
        {
            RedBalon balon = new RedBalon(_balonPanel.Size);
            balonlar.Add(balon);
            _balonPanel.Controls.Add(balon);

        }
        public void OkcuHareketEttir(Yon yon)   //basılan tuşa göre gönderilen yönde okçuyu yukarı aşağı hareket ettiriyor
        {
            okcu.HareketEttir(yon);
        }


    }
}
