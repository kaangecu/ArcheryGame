﻿using Okcu_Library.Enum;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Okcu_Library
{
    abstract class Cisim:PictureBox     //bütün hareketli objeler bu classtan türetiliyor 
    {

        public Size HareketAlaniBoyutlari { get; }

        public int HareketMesafesi { get; protected set; }

        protected Cisim(Size hareketAlaniBoyutlari)
        {
            HareketAlaniBoyutlari = hareketAlaniBoyutlari;
            SizeMode = PictureBoxSizeMode.AutoSize;
        }


        public bool HareketEttir(Yon yon)   //hareketli cisimlerde verilen yöne göre hareketi sağlar 
        {
            switch (yon)

            {
                case Yon.Yukarı:
                    return YukariGit();
                case Yon.Asagı:
                    return AsagıGit();
                case Yon.Sag:
                    return SagaGit();
                case Yon.Sol:
                    return SolaGit();
                default:
                    return false;
                    break;
            }
            
        }

        private bool SolaGit()      //sola giden bir obje olmadığından kullanılmıyor
        {
            throw new NotImplementedException();
        }

        private bool SagaGit()      //oklar için kullanılıyor
        {
            if (HareketAlaniBoyutlari.Width >= Left + HareketMesafesi)
            {
                Left = Left + HareketMesafesi;
                return false;
            }
            else
                return true;
        }

        private bool AsagıGit() 
        {
            if (HareketAlaniBoyutlari.Height >= Top + HareketMesafesi)
            {
                Top = Top + HareketMesafesi;
                return false;
            }
            else
                return true;
        }

        private bool YukariGit()
        {
            if(0 <= Top - HareketMesafesi)
            Top=Top - HareketMesafesi;

            return false;
        }
    }
}
