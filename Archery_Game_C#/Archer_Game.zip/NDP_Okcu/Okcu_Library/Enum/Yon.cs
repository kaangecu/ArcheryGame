﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Okcu_Library.Enum
{
    public enum Yon
    {
        Yukarı,
        Asagı,
        Sag,
        Sol
    }
}
