﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Okcu_Library.Balonlar
{
    abstract class Balon:Cisim
    {
        private static readonly Random Random = new Random();   //balonların rastgeleliği sağlanıyor
        public enum Renk { Yellow, Green, Red };        //çocuk balonlarda renklerin seçilmesi için

        public int Puan;                                //her balonun belli bir puanı var o çocuklarda belirleniyor
        public Renk renk;

        public Balon(Size hareketAlaniBoyutlari) : base(hareketAlaniBoyutlari)
        {

            Left = Random.Next(hareketAlaniBoyutlari.Width - Width+1);
            HareketMesafesi = 10;

        }

        public bool VurulduMu(List<Ok> oklar)       //tek tek bütün oklarla karşılaştırılmak üzere Liste gönderiliyor ve bunlar üzerinde bakılarak konumu balonla kesişen var mı kontrolü yapılıyor
        {
            foreach (var ok in oklar)
            {

                var vurulduMu = ok.Right > Left && ok.Bottom>Top && ok.Top<Bottom && ok.Left<Right;
                if (vurulduMu) return true;

            }

            return false;
        }
    }
}
