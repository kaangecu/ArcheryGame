﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NDP_Okcu_Odev
{
    public partial class OyuncuSec : Form       //kayıtlı oyuncular arasından seçim yaptırarak ona göre oyunu yüklüyor 
    {
        List<string> OyuncuBilgileri = new List<string>();
        private int i = 0;
        public OyuncuSec()
        {
            InitializeComponent();
            
            using (StreamReader r = new StreamReader(@"Text\player.txt"))       //kayıtlı oyuncuların olduğu dosyayı açıyor
            {
                string satir;
                while ((satir = r.ReadLine()) != null)
                {
                    string[] bilgiler = satir.Split(' ');

                    OyuncuComboBox.Items.Add(i+1+" - "+bilgiler[0] + " " + bilgiler[1]);    //comboboxta "numara-isim puan" olacak şekilde ekliyor
                    OyuncuBilgileri.Add(satir);                                             //oyuncu bilgilerini listeye ekliyor
                    i++;                                                                    //comboboxta sayıların sırası artırılıyor
                }
            }
            
        }

        private void OnayButton_Click(object sender, EventArgs e)
        {
            string[] sayiKonum = OyuncuComboBox.Text.Split(' ');                //kaç numaralı seçimin yapıldığını bulmak için boşluklardan ayrılıyor
            int no = (Int32.Parse(sayiKonum[0].ToString()) - 1);                //ilk konumda kalan sayı 1 eksiltiriliyor 
            string[] secilenOyuncuBilgileri = OyuncuBilgileri[no].Split(' '); ; //bu sayı listede yapılan seçile eşleştiriliyor
             
           
            OyunMenu oyunMenu = new OyunMenu(secilenOyuncuBilgileri);       //verilen bilgiler doğrultusunda oyun ekranı oluşturuluyor

            this.Hide();                                        //bu form gizleniyor
            oyunMenu.Closed += (s, args) => this.Close();       //arkada açık kalmaması için açılan formla kapanma eventleri bağlanıyor
            oyunMenu.Show();                                    
        }
    }
}
