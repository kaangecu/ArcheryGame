﻿namespace Okcu_Library
{
    partial class StartMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.YeniOyun = new System.Windows.Forms.Button();
            this.KayitliOyun = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.OkcuComboBox = new System.Windows.Forms.ComboBox();
            this.OkComboBox = new System.Windows.Forms.ComboBox();
            this.ArkaPlanComboBox = new System.Windows.Forms.ComboBox();
            this.OkcuPictureBox = new System.Windows.Forms.PictureBox();
            this.OkPictureBox = new System.Windows.Forms.PictureBox();
            this.ArkaPlanPictureBox = new System.Windows.Forms.PictureBox();
            this.OyuncuList = new System.Windows.Forms.ListBox();
            this.ScoreList = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.OyuncuAdiTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.OkcuPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OkPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ArkaPlanPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // YeniOyun
            // 
            this.YeniOyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.YeniOyun.Location = new System.Drawing.Point(403, 118);
            this.YeniOyun.Name = "YeniOyun";
            this.YeniOyun.Size = new System.Drawing.Size(155, 60);
            this.YeniOyun.TabIndex = 0;
            this.YeniOyun.Text = "Yeni Oyun";
            this.YeniOyun.UseVisualStyleBackColor = true;
            this.YeniOyun.Click += new System.EventHandler(this.YeniOyun_Click);
            // 
            // KayitliOyun
            // 
            this.KayitliOyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.KayitliOyun.Location = new System.Drawing.Point(403, 202);
            this.KayitliOyun.Name = "KayitliOyun";
            this.KayitliOyun.Size = new System.Drawing.Size(155, 60);
            this.KayitliOyun.TabIndex = 1;
            this.KayitliOyun.Text = "Kayıtlı Oyun";
            this.KayitliOyun.UseVisualStyleBackColor = true;
            this.KayitliOyun.Click += new System.EventHandler(this.KayitliOyun_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.PeachPuff;
            this.label1.Location = new System.Drawing.Point(395, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "Archery Training";
            // 
            // OkcuComboBox
            // 
            this.OkcuComboBox.FormattingEnabled = true;
            this.OkcuComboBox.Location = new System.Drawing.Point(65, 38);
            this.OkcuComboBox.Name = "OkcuComboBox";
            this.OkcuComboBox.Size = new System.Drawing.Size(121, 24);
            this.OkcuComboBox.TabIndex = 4;
            this.OkcuComboBox.SelectedIndexChanged += new System.EventHandler(this.OkcuComboBox_SelectedIndexChanged);
            // 
            // OkComboBox
            // 
            this.OkComboBox.FormattingEnabled = true;
            this.OkComboBox.Location = new System.Drawing.Point(65, 268);
            this.OkComboBox.Name = "OkComboBox";
            this.OkComboBox.Size = new System.Drawing.Size(121, 24);
            this.OkComboBox.TabIndex = 5;
            this.OkComboBox.SelectedIndexChanged += new System.EventHandler(this.OkComboBox_SelectedIndexChanged);
            // 
            // ArkaPlanComboBox
            // 
            this.ArkaPlanComboBox.FormattingEnabled = true;
            this.ArkaPlanComboBox.Location = new System.Drawing.Point(65, 393);
            this.ArkaPlanComboBox.Name = "ArkaPlanComboBox";
            this.ArkaPlanComboBox.Size = new System.Drawing.Size(121, 24);
            this.ArkaPlanComboBox.TabIndex = 6;
            this.ArkaPlanComboBox.SelectedIndexChanged += new System.EventHandler(this.ArkaPlanComboBox_SelectedIndexChanged);
            // 
            // OkcuPictureBox
            // 
            this.OkcuPictureBox.Location = new System.Drawing.Point(65, 68);
            this.OkcuPictureBox.Name = "OkcuPictureBox";
            this.OkcuPictureBox.Size = new System.Drawing.Size(121, 182);
            this.OkcuPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.OkcuPictureBox.TabIndex = 7;
            this.OkcuPictureBox.TabStop = false;
            // 
            // OkPictureBox
            // 
            this.OkPictureBox.Location = new System.Drawing.Point(65, 313);
            this.OkPictureBox.Name = "OkPictureBox";
            this.OkPictureBox.Size = new System.Drawing.Size(216, 45);
            this.OkPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.OkPictureBox.TabIndex = 8;
            this.OkPictureBox.TabStop = false;
            // 
            // ArkaPlanPictureBox
            // 
            this.ArkaPlanPictureBox.Location = new System.Drawing.Point(65, 440);
            this.ArkaPlanPictureBox.Name = "ArkaPlanPictureBox";
            this.ArkaPlanPictureBox.Size = new System.Drawing.Size(291, 130);
            this.ArkaPlanPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ArkaPlanPictureBox.TabIndex = 9;
            this.ArkaPlanPictureBox.TabStop = false;
            // 
            // OyuncuList
            // 
            this.OyuncuList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.OyuncuList.FormattingEnabled = true;
            this.OyuncuList.ItemHeight = 18;
            this.OyuncuList.Location = new System.Drawing.Point(756, 118);
            this.OyuncuList.Name = "OyuncuList";
            this.OyuncuList.Size = new System.Drawing.Size(72, 292);
            this.OyuncuList.TabIndex = 11;
            this.OyuncuList.Tag = "";
            // 
            // ScoreList
            // 
            this.ScoreList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ScoreList.FormattingEnabled = true;
            this.ScoreList.ItemHeight = 18;
            this.ScoreList.Location = new System.Drawing.Point(844, 118);
            this.ScoreList.Name = "ScoreList";
            this.ScoreList.Size = new System.Drawing.Size(72, 292);
            this.ScoreList.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(753, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Oyuncu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(840, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 14;
            this.label3.Text = "Score";
            // 
            // OyuncuAdiTextBox
            // 
            this.OyuncuAdiTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.OyuncuAdiTextBox.Location = new System.Drawing.Point(219, 68);
            this.OyuncuAdiTextBox.Name = "OyuncuAdiTextBox";
            this.OyuncuAdiTextBox.Size = new System.Drawing.Size(100, 26);
            this.OyuncuAdiTextBox.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(215, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Oyuncu";
            // 
            // StartMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1006, 589);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.OyuncuAdiTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ScoreList);
            this.Controls.Add(this.OyuncuList);
            this.Controls.Add(this.ArkaPlanPictureBox);
            this.Controls.Add(this.OkPictureBox);
            this.Controls.Add(this.OkcuPictureBox);
            this.Controls.Add(this.ArkaPlanComboBox);
            this.Controls.Add(this.OkComboBox);
            this.Controls.Add(this.OkcuComboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.KayitliOyun);
            this.Controls.Add(this.YeniOyun);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "StartMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StartMenu";
            ((System.ComponentModel.ISupportInitialize)(this.OkcuPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OkPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ArkaPlanPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button YeniOyun;
        private System.Windows.Forms.Button KayitliOyun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox OkcuComboBox;
        private System.Windows.Forms.ComboBox OkComboBox;
        private System.Windows.Forms.ComboBox ArkaPlanComboBox;
        private System.Windows.Forms.PictureBox OkcuPictureBox;
        private System.Windows.Forms.PictureBox OkPictureBox;
        private System.Windows.Forms.PictureBox ArkaPlanPictureBox;
        private System.Windows.Forms.ListBox OyuncuList;
        private System.Windows.Forms.ListBox ScoreList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox OyuncuAdiTextBox;
        private System.Windows.Forms.Label label4;
    }
}