﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using NDP_Okcu_Odev;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Okcu_Library;

namespace Okcu_Library
{
    public partial class StartMenu : Form
    {
        string[] oyuncuBilgileri = new string[5];

        public StartMenu()
        {
            InitializeComponent();

            ComboBoxDoldur();


            using (StreamReader r = new StreamReader(@"Text\player.txt"))   //daha önceki oyuncu isimleri ve scoreları kenarda gösterilmek üzere dosyadan alınıyor
            {
                string satir;
                while ((satir = r.ReadLine()) != null)
                {                   
                    string[] bilgiler = satir.Split(' ');
                    
                    OyuncuList.Items.Add(bilgiler[0]);

                    int score = Int32.Parse(bilgiler[1]);                    
                    ScoreList.Items.Add(score);
                }
            }

        }

        private void YeniOyun_Click(object sender, EventArgs e) //eğer değerlerin hepsi tam şekilde girildiyse oyunu başlatma menüsüne yönlenriyor
        {
            if (OkComboBox.Text == "" || OkcuComboBox.Text == "" || ArkaPlanComboBox.Text == "")
                MessageBox.Show("Resim Seçimlerini Yapmadan Oyuna Başlayamazsınız");

            else if(OyuncuAdiTextBox.Text == "")
                MessageBox.Show("Oyuncu Adı Girin");

            else
            {
                oyuncuBilgileri[0] = OyuncuAdiTextBox.Text;
                OyunMenu oyunMenu = new OyunMenu(oyuncuBilgileri);
                
                this.Hide(); 
                oyunMenu.Closed += (s, args) => this.Close();
                oyunMenu.Show();
            }           
        }

        void ComboBoxDoldur()       //combobox opsiyonları atanıyor
        {
            OkcuComboBox.Items.Add("greenArrow");
            OkcuComboBox.Items.Add("femaleArcher");
            OkComboBox.Items.Add("tahtaOk");
            OkComboBox.Items.Add("yeşilOk");      
            ArkaPlanComboBox.Items.Add("Control");
            ArkaPlanComboBox.Items.Add("Chocolate");
            ArkaPlanComboBox.Items.Add("Salmon");

        }

        private void OkcuComboBox_SelectedIndexChanged(object sender, EventArgs e)  //comboboxlardaki değerler uygun formatta daha sonra file location olarak kullanılacak şekilde kaydediliyor
        {
            string imgLocation = @"Görseller\" + OkcuComboBox.Text + ".png";
            OkcuPictureBox.Image = Image.FromFile(imgLocation);
            oyuncuBilgileri[2]= imgLocation;
        }

        private void OkComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {           
                string imgLocation = @"Görseller\" + OkComboBox.Text + ".png";
                OkPictureBox.Image = Image.FromFile(imgLocation);
                oyuncuBilgileri[3] = imgLocation;
                       
        }

        private void ArkaPlanComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Color renk =  Color.FromName(ArkaPlanComboBox.Text);
            ArkaPlanPictureBox.BackColor = renk;
            oyuncuBilgileri[4] = ArkaPlanComboBox.Text;

        }

        private void KayitliOyun_Click(object sender, EventArgs e)  //kayıtlı oyuncudan oynanmak isteniyorsa seçim menüsüne yönlendiriyor 
        {
            OyuncuSec oyuncuMenu = new OyuncuSec();

            this.Hide();
            oyuncuMenu.Closed += (s, args) => this.Close();
            oyuncuMenu.Show();
        }


    }
}
