﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2020 YAZ DÖNEMİ
**	
**				ÖDEV NUMARASI..........: PROJE
**				ÖĞRENCİ ADI............: KAAN GECÜ
**				ÖĞRENCİ NUMARASI.......: B171210016
**              DERSİN ALINDIĞI GRUP...: 1A
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Okcu_Library;
using Okcu_Library.Enum;

namespace NDP_Okcu_Odev
{
    public partial class OyunMenu : Form
    {
        private readonly Oyun oyun;
        public OyunMenu(string[] oyuncuBilgileri)
        {
            InitializeComponent();

            oyun = new Oyun(OkcuPanel,AnaPanel, BalonPanel, oyuncuBilgileri); 

            oyun.GecenSureEvent += GecenSureDegisti;
            oyun.PuanDegistiEvent += PuanDegisti;
            oyun.Baslat();

        }



        private void GecenSureDegisti(object sender, EventArgs e)
        {
            TimeLabel.Text = oyun.GecenSure.ToString(@"m\:ss");     //süreyi uygun formatta labela yazıyor
        }

        private void PuanDegisti(object sender, EventArgs e)
        {
            PuanLabel.Text = oyun.Puan.ToString();
        }

        private void OyunMenu_KeyDown(object sender, KeyEventArgs e)    //basılan tuşlaragöre okçu hareket ve ok işlemleri yapıyor
        {
            
            if(oyun.DevamEdiyorMu)
            switch(e.KeyCode)
            {
                case Keys.W:
                    oyun.OkcuHareketEttir(Yon.Yukarı);
                    break;

                case Keys.Up:
                    oyun.OkcuHareketEttir(Yon.Yukarı);
                    break;

                case Keys.S:
                    oyun.OkcuHareketEttir(Yon.Asagı);
                    break;

                case Keys.Down:
                    oyun.OkcuHareketEttir(Yon.Asagı);
                    break;

                case Keys.Space:
                    oyun.AtesEt();
                    break;
            }
            
        }
    }
}
