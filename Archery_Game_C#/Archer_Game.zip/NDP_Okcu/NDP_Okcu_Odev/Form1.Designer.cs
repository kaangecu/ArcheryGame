﻿namespace NDP_Okcu_Odev
{
    partial class OyunMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ScoreBoard = new System.Windows.Forms.Panel();
            this.TimeLabel = new System.Windows.Forms.Label();
            this.AnaPanel = new System.Windows.Forms.Panel();
            this.BalonPanel = new System.Windows.Forms.Panel();
            this.OkcuPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.PuanLabel = new System.Windows.Forms.Label();
            this.ScoreBoard.SuspendLayout();
            this.AnaPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ScoreBoard
            // 
            this.ScoreBoard.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ScoreBoard.Controls.Add(this.PuanLabel);
            this.ScoreBoard.Controls.Add(this.label1);
            this.ScoreBoard.Controls.Add(this.TimeLabel);
            this.ScoreBoard.Dock = System.Windows.Forms.DockStyle.Top;
            this.ScoreBoard.Location = new System.Drawing.Point(0, 0);
            this.ScoreBoard.Name = "ScoreBoard";
            this.ScoreBoard.Size = new System.Drawing.Size(1182, 89);
            this.ScoreBoard.TabIndex = 0;
            // 
            // TimeLabel
            // 
            this.TimeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TimeLabel.AutoSize = true;
            this.TimeLabel.Font = new System.Drawing.Font("Monotype Corsiva", 25.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TimeLabel.Location = new System.Drawing.Point(994, 19);
            this.TimeLabel.Name = "TimeLabel";
            this.TimeLabel.Size = new System.Drawing.Size(91, 52);
            this.TimeLabel.TabIndex = 0;
            this.TimeLabel.Text = "0:00";
            // 
            // AnaPanel
            // 
            this.AnaPanel.BackColor = System.Drawing.SystemColors.Info;
            this.AnaPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.AnaPanel.Controls.Add(this.BalonPanel);
            this.AnaPanel.Controls.Add(this.OkcuPanel);
            this.AnaPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AnaPanel.Location = new System.Drawing.Point(0, 89);
            this.AnaPanel.Name = "AnaPanel";
            this.AnaPanel.Size = new System.Drawing.Size(1182, 664);
            this.AnaPanel.TabIndex = 1;
            // 
            // BalonPanel
            // 
            this.BalonPanel.BackColor = System.Drawing.Color.Transparent;
            this.BalonPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BalonPanel.Location = new System.Drawing.Point(165, 0);
            this.BalonPanel.Name = "BalonPanel";
            this.BalonPanel.Size = new System.Drawing.Size(1017, 664);
            this.BalonPanel.TabIndex = 1;
            // 
            // OkcuPanel
            // 
            this.OkcuPanel.BackColor = System.Drawing.Color.Transparent;
            this.OkcuPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.OkcuPanel.Location = new System.Drawing.Point(0, 0);
            this.OkcuPanel.Name = "OkcuPanel";
            this.OkcuPanel.Size = new System.Drawing.Size(165, 664);
            this.OkcuPanel.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(147, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Puan:";
            // 
            // PuanLabel
            // 
            this.PuanLabel.AutoSize = true;
            this.PuanLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.PuanLabel.ForeColor = System.Drawing.Color.OrangeRed;
            this.PuanLabel.Location = new System.Drawing.Point(246, 27);
            this.PuanLabel.Name = "PuanLabel";
            this.PuanLabel.Size = new System.Drawing.Size(0, 39);
            this.PuanLabel.TabIndex = 2;
            // 
            // OyunMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 753);
            this.Controls.Add(this.AnaPanel);
            this.Controls.Add(this.ScoreBoard);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "OyunMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OkçuOyunu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OyunMenu_KeyDown);
            this.ScoreBoard.ResumeLayout(false);
            this.ScoreBoard.PerformLayout();
            this.AnaPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ScoreBoard;
        private System.Windows.Forms.Label TimeLabel;
        private System.Windows.Forms.Panel AnaPanel;
        private System.Windows.Forms.Panel OkcuPanel;
        private System.Windows.Forms.Panel BalonPanel;
        private System.Windows.Forms.Label PuanLabel;
        private System.Windows.Forms.Label label1;
    }
}

